#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <ros/ros.h>
#include <mover_client/grid_num.h>
#include <mover_client/grid_num_vector.h>
#include <iterator>
#include <string>
#include <stdio.h>
#include <string.h>
#include <sstream>

using namespace std;

bool addfactstofile(const mover_client::grid_num_vector &message);
string checkandreadsolution(mover_client::grid_num_vector &vectorsolution);
ros::Publisher pub;

//when message arrives call clingo and the extract result
void MsgAcquired(const mover_client::grid_num_vector &message)
{
	mover_client::grid_num sol;
	mover_client::grid_num_vector solutionvector;


	ROS_INFO_STREAM("Received Puzzle: ");
	
	//call clingo to get results
	if (addfactstofile(message))
	{
		try
		{
			system("./sudoku/clingo sudoku/sudokufacts.lp sudoku/ASP_sudoku.lp > sudoku/result.txt");
		}
		catch (const std::exception &e)
		{
			ROS_INFO_STREAM("Clingo: " << e.what());
			return;
		}
	}
	else
	{
		ROS_INFO_STREAM("Writing fail to sudofact file.");
		return;
	}

       //read solution and turn the values into desired message type
	string result = checkandreadsolution(solutionvector);

       //if satisfiable publish the solutionvector
	if (!result.compare("SATISFIABLE"))
	{
		pub.publish(solutionvector);
	}
	else 
	{
		ROS_INFO_STREAM("Result could not be acquired: " << result); 
	}
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "interface_node");
	ros::NodeHandle nh;

	pub = nh.advertise<mover_client::grid_num_vector>("num_grids_sol/vector", 1000);
	ros::Subscriber sub = nh.subscribe("num_grids/vector", 1000, &MsgAcquired);

	ros::spin();
}

bool addfactstofile(const mover_client::grid_num_vector &message)
{
	ofstream sudoku_facts;

	sudoku_facts.open("sudoku/sudokufacts.lp");

	if (sudoku_facts.fail())
	{
		ROS_INFO_STREAM("Failed opening file.");
		return false;
	}

	
	for (int i = 0; i < message.numbered_grids.size(); i++)
	{
		ROS_INFO_STREAM("(" << message.numbered_grids[i].row << "," << message.numbered_grids[i].col << "," << message.numbered_grids[i].num << ")");
		sudoku_facts << "sudoku(" << message.numbered_grids[i].row << "," << message.numbered_grids[i].col << "," << message.numbered_grids[i].num << "). ";
	}
	sudoku_facts.close();
	return true;
}

string checkandreadsolution(mover_client::grid_num_vector &vectorsolution)
{
	ifstream solutionfile;
	solutionfile.open("sudoku/result.txt");
	string satisfiability;
	
	if(solutionfile.fail())
	{
		ROS_INFO_STREAM("Failed opening file.");
		return "ERROR IN FILE";
	}

	// search for the satisfiability status
	bool found = false;
	string content((istreambuf_iterator<char>(solutionfile)), (istreambuf_iterator<char>()));
	size_t pos;
	solutionfile.close();
        
        //check if solution is satisfiable
	if (content.find("SATISFIABLE")!=string::npos)
	{
		found=true;
		pos = content.find("SATISFIABLE");
		satisfiability = "SATISFIABLE";
		content.erase(pos,content.length());
	}
	
	if (content.find("UNSATISFIABLE")!=string::npos)
	{

		pos = content.find("UNSATISFIABLE");
		satisfiability = "UNSATISFIABLE";
	}
	
	if(content.find("UNKNOWN")!=string::npos)
	{
		pos = content.find("UNKNOWN");
		satisfiability = "UNKNOWN";
	}
	
	//if satisfiable, take string and find the sudoku values, and place them in grid_num, and store them in vector to send back message
	if(found)
	{
		size_t found1 = content.find("sudoku(");
		content.erase(0,found1);
		
		int n = content.length();
		char rest[n+1];
		char* token1;
		char * rest1 = rest;
		strcpy(rest1, content.c_str());	
	
		while ((token1 = strtok_r(rest1, " ", &rest1)))
		{
			string s(token1);
			vector<int> a;
			for (size_t i = 0; i < s.size();) 
			{

				// Basically, we want to continue with the next character in the next loop run
				size_t increments{1};

				// If the current character is a digit, then we convert this and the following characters to an int
				if (std::isdigit(s[i])) 
				{
				    // The stoi function will inform us, how many characters have been converted.
				    a.emplace_back(std::stoi(s.substr(i), &increments));
				}
				// Either +1 or plus the number of converted characters
				i += increments;
			}

                       //place numbered values from sudoku solution into grid_num message type and place it into vector
			mover_client::grid_num hold;
			hold.row = a[0];
			hold.col = a[1];
			hold.num = a[2];
			vectorsolution.numbered_grids.push_back(hold);    
		}
		
		
	}
	
	return satisfiability;
}
