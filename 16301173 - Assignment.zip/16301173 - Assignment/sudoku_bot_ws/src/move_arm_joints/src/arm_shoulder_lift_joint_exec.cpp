#include <ros/ros.h>
#include <move_arm_joints/move_and_confirm.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

bool mover_call(move_arm_joints::move_and_confirm::Request &req,
					 move_arm_joints::move_and_confirm::Response &resp)
{
	ifstream log;
	string logString, prevString;
	do
	{
		//Prepare system string
		string temp("./arm_shoulder_lift_servo " + to_string(req.move));
		try
		{
			system(temp.c_str());
		}
		catch (const std::exception &e)
		{
			ROS_INFO_STREAM("Failed to call arm_shoulder_lift_servo: " << e.what());
			return false;
		}

		//Open log file
		log.open("arm_shoulder_lift_servo_confirm.log");
		if (log.fail())
		{
			ROS_INFO_STREAM("Fail to open arm_shoulder_lift_servo_confirm.log");
			return false;
		}

		//get last line of logfile
		do
		{
			prevString = logString;
		}while (getline(log, logString));
		
		//Convert it to double
		resp.confirm = stod(prevString);

		log.close();
	} while (req.move != resp.confirm);
	return true;
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "arm_shoulder_lift_joint_node");
	ros::NodeHandle nh;
	ros::ServiceServer myServer = nh.advertiseService("arm_shoulder_lift_joint_node/arm_shoulder_lift_joint_service", &mover_call);

	ros::spin();

	return 0;
}
