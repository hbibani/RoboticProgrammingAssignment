#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <map>
#include <iterator>
#include <vector>
#include <bits/stdc++.h>
#include <ros/ros.h>
#include <mover_client/grid_num.h>
#include <mover_client/grid_num_vector.h>
#include <move_arm_joints/move_and_confirm.h>

using namespace std;


ros::ServiceClient arm_shoulder_pan_joint_client;
ros::ServiceClient arm_elbow_flex_joint_client;
ros::ServiceClient arm_wrist_flex_joint_client;
ros::ServiceClient arm_shoulder_lift_joint_client;
ros::ServiceClient gripper_joint_client;

//dictionary map which uses the string as a find, and vector used to store all decimal values in each row of the csv file 
map<string, vector<double>> searchAllParam;

//class used for dictionary and vectors values
class numberedgridsvalues
{
	public:
	string find;
	int row;
	int col;
	int num;

};

//create dictionary from param.csv file
bool dictionary_param_creation()
{
	ifstream param;
	string line, colname;
	map<string, double> joint_param;
	
	
	param.open("param.csv");
	if (param.fail())
	{
		ROS_INFO_STREAM("Fail to open the parameter file.");
		return false;
	}

	getline(param, line); // ignore the headers

	//Read data, line by line
	while (getline(param, line))
	{
		//Create a stringstream of the current line
		stringstream ss(line);
		vector<double> results;
		double val;
		string token;
		
		int count = 0;
		
		string addvalue = "";
		while(getline(ss, token, ','))
		{
			if(count <= 2)
			{
				addvalue = addvalue + token;
			}
			
			if(count > 2)
			{
				results.push_back(stod(token));
			}
			
			count++;
		}
		
		count = 0;
		searchAllParam.insert({addvalue, results});
	}
	

	param.close();
	return true;
}

void solGot(const mover_client::grid_num_vector &msg)
{
	move_arm_joints::move_and_confirm::Request req;
	move_arm_joints::move_and_confirm::Response resp;


	vector<numberedgridsvalues> vectorvalues;
        //create vector from the message received and store them in the numberedgridvalues class, this will be used to find decimal values in the dictionary
	for(int i = 0; i < msg.numbered_grids.size(); i++)
	{
		string add = "";
		numberedgridsvalues addvalues;
		add = add + to_string(msg.numbered_grids[i].row) + to_string(msg.numbered_grids[i].col) + to_string(msg.numbered_grids[i].num);
		addvalues.find = add;
		addvalues.row = msg.numbered_grids[i].row;
		addvalues.col = msg.numbered_grids[i].col;
		addvalues.num = msg.numbered_grids[i].num; 
		vectorvalues.push_back(addvalues);
	}

        //iterator used to find the values in the dictionary using the variable called find using the message received
	map<string, vector<double>>::iterator itr;

	//call the needed values by referencing the dictionary and iterating through the values of the sudoku's taken from the message
	for(int i = 0; i < vectorvalues.size(); i++)
	{
		ROS_INFO_STREAM("m_client: sudoku(" << vectorvalues[i].row << "," << vectorvalues[i].col << "," << vectorvalues[i].num << ")");
		itr=searchAllParam.find(vectorvalues[i].find);

		req.move = itr->second[0];
		if(arm_shoulder_pan_joint_client.call(req, resp))
		{
			ROS_INFO_STREAM("m_client: arm_shoulder_pan_joint(req: " << req.move << ", " << "resp: " << resp.confirm << ")");
		}
		else
		{
			ROS_ERROR("Failed to call arm_shoulder_pan_joint");
		}
		
		req.move = itr->second[1];
		if(arm_elbow_flex_joint_client.call(req, resp))
		{
			ROS_INFO_STREAM("m_client: arm_elbow_flex_joint(req: " << req.move << ", " << "resp: " << resp.confirm << ")");
		}
		else
		{
			ROS_ERROR("Failed to call arm_elbow_flex_joint");
		}
		
		req.move = itr->second[2];
		if(arm_wrist_flex_joint_client.call(req, resp))
		{
			ROS_INFO_STREAM("m_client: arm_wrist_flex_joint(req: " << req.move << ", " << "resp: " << resp.confirm << ")");
		}
		else
		{
			ROS_ERROR("Failed to call arm_wrist_flex_joint");
		}
		
		req.move = itr->second[3];
		if(arm_shoulder_lift_joint_client.call(req, resp))
		{
			ROS_INFO_STREAM("m_client: arm_shoulder_lift_joint(req: " << req.move << ", " << "resp: " << resp.confirm << ")");
		}
		else
		{
			ROS_ERROR("Failed to call arm_shoulder_lift_joint");
		}
		
		req.move = itr->second[4];
		if(gripper_joint_client.call(req, resp))
		{
			ROS_INFO_STREAM("m_client: gripper_joint(req: " << req.move << ", " << "resp: " << resp.confirm << ")");
		}
		else
		{
			ROS_ERROR("Failed to call gripper_joint");
		}
	}
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "mover_client_node");
	ros::NodeHandle nh;
	ros::Subscriber sub = nh.subscribe("num_grids_sol/vector", 1000, &solGot);

	//create dictionary from csv file
	if (!dictionary_param_creation()) {
		ROS_INFO_STREAM("Parameter file could not be instantiated.");
		return -1;
	}

	//create service clients to the appropriate service, so that the joints can be called in function called solGot
	arm_shoulder_pan_joint_client = nh.serviceClient<move_arm_joints::move_and_confirm>("arm_shoulder_pan_joint_node/arm_shoulder_pan_joint_service");
	arm_elbow_flex_joint_client = nh.serviceClient<move_arm_joints::move_and_confirm>("arm_elbow_flex_joint_node/arm_elbow_flex_joint_service");
	arm_shoulder_lift_joint_client = nh.serviceClient<move_arm_joints::move_and_confirm>("arm_shoulder_lift_joint_node/arm_shoulder_lift_joint_service");
	arm_wrist_flex_joint_client = nh.serviceClient<move_arm_joints::move_and_confirm>("arm_wrist_flex_joint_node/arm_wrist_flex_joint_service");
	gripper_joint_client = nh.serviceClient<move_arm_joints::move_and_confirm>("gripper_joint_node/gripper_joint_service");

	ros::spin();
}
